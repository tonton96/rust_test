use tonic::{transport::Server, Request, Response, Status};
use person::person_server::{Person, PersonServer};
use person::{UserRequest, UserResponse};

pub mod person {
    tonic::include_proto!("person");
}

#[derive(Debug, Default)]
pub struct MyPerson;

#[tonic::async_trait]
impl Person for MyPerson {
    async fn send_user(&self, request: Request<UserRequest>) -> Result<Response<UserResponse>, Status> {
        let req = request.into_inner();
        let reply = person::UserResponse {
            message: format!("Hello {}", req.name).into(),
        };
        Ok(Response::new(reply))
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let addr = "[::1]:50041".parse()?;
    let person = MyPerson::default();

    println!("Server is listening ...");
    Server::builder().add_service(PersonServer::new(person)).serve(addr).await?;

    Ok(())
}
