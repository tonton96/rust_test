use person::person_client::PersonClient;
use person::UserRequest;

pub mod person {
    tonic::include_proto!("person");
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut client = PersonClient::connect("http://[::1]:50041").await?;

    let request = tonic::Request::new(UserRequest { name: "Hiii".to_owned(), });
    
    let response = client.send_user(request).await?;
    println!("RESPONSE={:?}", response);

    Ok(())
}
